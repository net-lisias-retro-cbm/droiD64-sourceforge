#!/bin/sh
CPATH=lib/droid64-0.5b.jar:lib/jaxb-impl-2.3.3.jar:lib/jakarta.activation-1.2.2.jar:lib/postgresql-42.2.18.jar:lib/protobuf-java-3.11.4.jar:lib/checker-qual-3.5.0.jar:lib/jakarta.xml.bind-api-2.3.3.jar:lib/mysql-connector-java-8.0.22.jar:lib/jakarta.activation-api-1.2.2.jar
exec java -classpath $CPATH -Xmx1024m droid64.DroiD64 $*
